# mobilitydemo-motcamside Helm chart

```bash
# Registry privado de GitLab
kubectl create secret docker-registry gitlab-registry \
  --docker-server=gitlab.i2cat.net:5050 --docker-username=<user> --docker-password=<token>

helm install motcamside ./mobilitydemo-motcamside \
  --set imagePullSecrets[0].name=gitlab-registry \
  --set image.tag=v0.1.0 \
  --set config.motcam.host=motcam-mqtt.edge.svc.cluster.local \
  --set config.fiveg.host=5g-v2x-mqtt.cloud.svc.cluster.local
```

Para pruebas: `--set mockPublisher.enabled=true`.
Para Prometheus Operator: `--set metrics.serviceMonitor.enabled=true`.
