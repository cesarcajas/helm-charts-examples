# K8s-Orchestrator-deployment 

 [Kubernetes API Overview](https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.29/#api-overview).
For more detailed information on how to deploy a helm chart, go to the following [document](https://docs.google.com/document/d/1g-k68CyP0NlsxU6Uh-HX4U-xM7qIg2g3G9Dv4PqFn2k/edit).

## Name
K8s Orchestrator Deployment.

## Description
This repository is the automation of the deployment of the Orchestrator and child componentes for kubernetes clusters. It is based in a helm chart that can be installed and deployed to provide access to the orchestrator. 

The chart gives the opportunity to select the elements to deploy from the k8s elements included in the image below. For exposing the pods via Loadbalancer services, the helmchart assumes metallb is installed. 
![Holomit K8s Deployment](schemes/Holomit-k8s-Deployment.png)

## Prerequisites
- [Helm](https://helm.sh/docs/intro/install/ ) installed.
- To configure external acess with Loadbalancer services, the helmchart assumes [metallb](https://metallb.io/) is installed. Otherwise the services can be configured as nodeport.


## Usage
```
cd k8s-orchestrator-deployment
check values.yaml to configure external ips and ports
helm install orchestrator .
```

## Known Errors
- #### The push-GW server should expose https for the client to send metrics.

  We fixed this issue in the corresponding environments raising a reverse proxy to add the certificates

