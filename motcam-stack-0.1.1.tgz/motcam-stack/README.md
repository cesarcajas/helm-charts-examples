# motcam-stack

Traducción a Helm del docker-compose de demo MOTCAM.

| compose | chart |
|---|---|
| motcam_core + buffer_cleaner | Deployment `core` (2 contenedores, comparten `/tmp`) |
| motcam_trajectories / geolocalization | Deployments |
| motcam_flexstack (+ flexstack.cfg) | Deployment; config.cfg generado, token inyectado desde el Secret |
| mosquitto (+ mosquitto.conf) | Deployment + Service + ConfigMap |
| influxdb2 (+ init-influxdb.sh) | StatefulSet + Service + Secret + ConfigMap del script |
| motcam_visualization | **No incluido** (necesita X11/display) |

```bash
helm install motcam ./motcam-stack -n motcam --create-namespace \
  --set imagePullSecrets[0].name=gitlab-registry
```
