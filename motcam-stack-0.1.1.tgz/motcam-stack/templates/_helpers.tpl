{{- define "motcam.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "motcam.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "motcam.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Uso: include "motcam.selectorLabels" (dict "ctx" . "component" "core") */}}
{{- define "motcam.selectorLabels" -}}
app.kubernetes.io/name: {{ include "motcam.name" .ctx }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{- define "motcam.labels" -}}
helm.sh/chart: {{ include "motcam.chart" .ctx }}
{{ include "motcam.selectorLabels" . }}
app.kubernetes.io/version: {{ .ctx.Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .ctx.Release.Service }}
{{- end }}

{{- define "motcam.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "motcam.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "motcam.influxSecretName" -}}
{{- default (printf "%s-influxdb" (include "motcam.fullname" .)) .Values.influxdb.auth.existingSecret }}
{{- end }}

{{/* Uso: include "motcam.env" (dict "root" $ "env" .env "extraEnv" .extraEnv) */}}
{{- define "motcam.env" -}}
- name: TZ
  value: {{ .root.Values.timezone | quote }}
{{- range $k, $v := .env }}
- name: {{ $k }}
  value: {{ $v | quote }}
{{- end }}
{{- with .extraEnv }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{- define "motcam.hostNetwork" -}}
{{- if . }}
hostNetwork: true
dnsPolicy: ClusterFirstWithHostNet
{{- end }}
{{- end }}

{{- define "motcam.scheduling" -}}
{{- with .nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{- define "motcam.waitInfluxContainer" -}}
- name: wait-for-influxdb
  image: {{ .Values.waitForInfluxdb.image }}
  command:
    - sh
    - -c
    - until wget -qO- http://{{ include "motcam.fullname" . }}-influxdb:{{ .Values.influxdb.service.port }}/health >/dev/null 2>&1; do echo "esperando a influxdb..."; sleep 3; done
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
{{- end }}

{{- define "motcam.waitInflux" -}}
{{- if and .Values.influxdb.enabled .Values.waitForInfluxdb.enabled }}
initContainers:
  {{- include "motcam.waitInfluxContainer" . | nindent 2 }}
{{- end }}
{{- end }}

{{- define "motcam.dataVolume" -}}
{{- $d := .Values.core.data }}
- name: data
{{- if eq $d.type "pvc" }}
  persistentVolumeClaim:
    claimName: {{ default (printf "%s-core-data" (include "motcam.fullname" .)) $d.existingClaim }}
{{- else if eq $d.type "hostPath" }}
  hostPath:
    path: {{ required "core.data.hostPath es obligatorio si core.data.type=hostPath" $d.hostPath }}
    type: DirectoryOrCreate
{{- else }}
  emptyDir: {}
{{- end }}
{{- end }}
