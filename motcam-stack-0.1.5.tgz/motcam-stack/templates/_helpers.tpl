{{- define "motcam.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "motcam.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "motcam.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Uso: include "motcam.selectorLabels" (dict "ctx" . "component" "core") */}}
{{- define "motcam.selectorLabels" -}}
app.kubernetes.io/name: {{ include "motcam.name" .ctx }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{- define "motcam.labels" -}}
helm.sh/chart: {{ include "motcam.chart" .ctx }}
{{ include "motcam.selectorLabels" . }}
app.kubernetes.io/version: {{ .ctx.Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .ctx.Release.Service }}
{{- end }}

{{- define "motcam.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "motcam.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "motcam.influxSecretName" -}}
{{- default (printf "%s-influxdb" (include "motcam.fullname" .)) .Values.influxdb.auth.existingSecret }}
{{- end }}

{{/* Uso: include "motcam.env" (dict "root" $ "env" .env "extraEnv" .extraEnv) */}}
{{- define "motcam.env" -}}
- name: TZ
  value: {{ .root.Values.timezone | quote }}
{{- range $k, $v := .env }}
- name: {{ $k }}
  value: {{ $v | quote }}
{{- end }}
{{- with .extraEnv }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{- define "motcam.hostNetwork" -}}
{{- if . }}
hostNetwork: true
dnsPolicy: ClusterFirstWithHostNet
{{- end }}
{{- end }}

{{- define "motcam.scheduling" -}}
{{- with .nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{- define "motcam.waitInfluxContainer" -}}
- name: wait-for-influxdb
  image: {{ .Values.waitForInfluxdb.image }}
  command:
    - sh
    - -c
    - until wget -qO- http://{{ include "motcam.fullname" . }}-influxdb:{{ .Values.influxdb.service.port }}/health >/dev/null 2>&1; do echo "esperando a influxdb..."; sleep 3; done
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
{{- end }}

{{- define "motcam.waitInflux" -}}
{{- if and .Values.influxdb.enabled .Values.waitForInfluxdb.enabled }}
initContainers:
  {{- include "motcam.waitInfluxContainer" . | nindent 2 }}
{{- end }}
{{- end }}

{{- define "motcam.dataVolume" -}}
{{- $d := .Values.core.data }}
- name: data
{{- if eq $d.type "pvc" }}
  persistentVolumeClaim:
    claimName: {{ default (printf "%s-core-data" (include "motcam.fullname" .)) $d.existingClaim }}
{{- else if eq $d.type "hostPath" }}
  hostPath:
    path: {{ required "core.data.hostPath es obligatorio si core.data.type=hostPath" $d.hostPath }}
    type: DirectoryOrCreate
{{- else }}
  emptyDir: {}
{{- end }}
{{- end }}

{{/* initContainer que copia la config INI de la imagen y reescribe url/token/org/bucket de [influxdb] */}}
{{- define "motcam.influxCfgInit" -}}
- name: render-influx-config
  image: "{{ .cfg.image.repository }}:{{ .cfg.image.tag }}"
  imagePullPolicy: {{ .cfg.image.pullPolicy }}
  env:
    - name: SRC
      value: {{ required "influxConfig.path es obligatorio si influxConfig.enabled=true" .cfg.influxConfig.path | quote }}
    - name: INFLUX_URL
      value: "http://{{ include "motcam.fullname" .root }}-influxdb:{{ .root.Values.influxdb.service.port }}"
    - name: INFLUX_ORG
      value: {{ .root.Values.influxdb.org | quote }}
    - name: INFLUX_BUCKET
      value: {{ .root.Values.influxdb.bucket | quote }}
    - name: INFLUX_TOKEN
      valueFrom:
        secretKeyRef:
          name: {{ include "motcam.influxSecretName" .root }}
          key: db_token
  command:
    - sh
    - -c
    - |
      set -e
      awk -v url="$INFLUX_URL" -v tok="$INFLUX_TOKEN" -v org="$INFLUX_ORG" -v bucket="$INFLUX_BUCKET" '
        /^[[:space:]]*\[/ { sec=$0; gsub(/[[:space:]]/, "", sec) }
        sec=="[influxdb]" && /^[[:space:]]*url[[:space:]]*=/    { print "url = " url; next }
        sec=="[influxdb]" && /^[[:space:]]*token[[:space:]]*=/  { print "token = " tok; next }
        sec=="[influxdb]" && /^[[:space:]]*org[[:space:]]*=/    { print "org = " org; next }
        sec=="[influxdb]" && /^[[:space:]]*bucket[[:space:]]*=/ { print "bucket = " bucket; next }
        { print }
      ' "$SRC" > /out/rendered.cfg
      grep -q "^url = $INFLUX_URL" /out/rendered.cfg
      grep -q "^token = " /out/rendered.cfg
  securityContext:
    allowPrivilegeEscalation: false
  volumeMounts:
    - name: influx-cfg
      mountPath: /out
{{- end }}

{{- define "motcam.initContainersFor" -}}
{{- $root := .root }}
{{- $cfg := .cfg }}
{{- $wait := and $root.Values.influxdb.enabled $root.Values.waitForInfluxdb.enabled }}
{{- if or $wait $cfg.influxConfig.enabled }}
initContainers:
  {{- if $wait }}
  {{- include "motcam.waitInfluxContainer" $root | nindent 2 }}
  {{- end }}
  {{- if $cfg.influxConfig.enabled }}
  {{- include "motcam.influxCfgInit" (dict "root" $root "cfg" $cfg) | nindent 2 }}
  {{- end }}
{{- end }}
{{- end }}
